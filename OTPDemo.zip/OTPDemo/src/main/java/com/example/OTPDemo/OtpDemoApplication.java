package com.example.OTPDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtpDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OtpDemoApplication.class, args);
	}

}
