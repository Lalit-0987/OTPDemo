package com.example.OTPDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtpDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
